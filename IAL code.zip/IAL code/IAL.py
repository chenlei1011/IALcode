#!/usr/bin/python3
#coding=utf-8
import math
import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net  import F3Net
from apex import amp
import numpy as np
from dfl import DFL
import cv2
import os

def IAL(outputs, labels, epoch, step):
    loss_CE = F.binary_cross_entropy_with_logits(outputs, labels, reduce='none')
    #loss_CE = loss_CE.mean()
    p = torch.sigmoid(outputs)
    p = p.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    labels = labels.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    #w1 = 4
    w1 = 1.5+0.5 * np.sin((epoch + 1) * math.pi / 64)
    chen11 = w1 - w1 / (1 + torch.exp(-10 * (p - 0.5))) + w1-w1*(p**2)
    #chen11 = 5*torch.exp(-5 * (p - 0.5)) / ((1 + torch.exp(-5 * (p - 0.5)))**2)
    chen11 = chen11 * labels
    chen12 = w1 / (1 + torch.exp(-10 * (p - 0.5))) + w1-w1*((1-p)**2)
    #chen12 = 5 * torch.exp(-5 * (p - 0.5)) / ((1 + torch.exp(-5 * (p - 0.5))) ** 2)
    chen12 = chen12 * (1-labels)
    chen0 = chen11 + chen12
    """
    b1 = p * labels + 1*(1-labels)
    #b1 = p * labels
    chen11 = w1 - w1 / (1 + torch.exp(-10 * (b1 - 0.5)))
    b2 = p * (1-labels)
    chen12 = w1 / (1 + torch.exp(-10 * (b2 - 0.5)))   
    loss1 = (1 ** 2) * torch.mean(torch.sum(chen11, dim=1))
    loss2 = (1 ** 2) * torch.mean(torch.sum(chen12, dim=1))
    """
    loss0 = (1 ** 2) * torch.mean(torch.sum(chen0, dim=1))
    KD_loss = loss_CE + loss0
    return KD_loss
